const NUMS = [20,19,18,17,16,15,14,13,12,'BULL'];
const VALS = [20,19,18,17,16,15,14,13,12,25];
let state = {
  names:['Player 1','Player 2'],
  logos:[null,null],
  hits:[new Array(10).fill(0), new Array(10).fill(0)]
};

try{
  const saved = localStorage.getItem('cricket_darts_v1');
  if(saved) state = JSON.parse(saved);
}catch(e){}

function save(){
  try{ localStorage.setItem('cricket_darts_v1', JSON.stringify(state)); }catch(e){}
}

function marksFor(h){
  const c = Math.min(h,3);
  return ['','/','Λ','▲'][c];
}

const board = document.getElementById('board');

function buildBoard(){
  board.innerHTML = '';
  NUMS.forEach((n,i)=>{
    const row = document.createElement('div');
    row.className = 'row' + (n==='BULL' ? ' bull' : '');
    row.innerHTML = `
      <div class="cell p1side">
        <input class="hits-input" type="number" min="0" inputmode="numeric" data-side="0" data-i="${i}" value="0">
        <span class="marks" data-marks="0-${i}"></span>
        <span class="pts" data-pts="0-${i}"></span>
      </div>
      <div class="num">${n}</div>
      <div class="cell p2side">
        <span class="pts" data-pts="1-${i}"></span>
        <span class="marks" data-marks="1-${i}"></span>
        <input class="hits-input" type="number" min="0" inputmode="numeric" data-side="1" data-i="${i}" value="0">
      </div>
    `;
    board.appendChild(row);
  });
  board.querySelectorAll('.hits-input').forEach(inp=>{
    inp.addEventListener('input', ()=>{
      const side = +inp.dataset.side, i = +inp.dataset.i;
      const v = Math.max(0, parseInt(inp.value,10) || 0);
      state.hits[side][i] = v;
      save(); update();
    });
  });
}

function update(){
  NUMS.forEach((n,i)=>{
    const h1 = state.hits[0][i], h2 = state.hits[1][i], val = VALS[i];
    const pts1 = (h1>=3 && h2<3) ? (h1-3)*val : 0;
    const pts2 = (h2>=3 && h1<3) ? (h2-3)*val : 0;

    const in1 = board.querySelector(`.hits-input[data-side="0"][data-i="${i}"]`);
    const in2 = board.querySelector(`.hits-input[data-side="1"][data-i="${i}"]`);
    if(document.activeElement !== in1) in1.value = h1;
    if(document.activeElement !== in2) in2.value = h2;
    board.querySelector(`[data-marks="0-${i}"]`).textContent = marksFor(h1);
    board.querySelector(`[data-marks="1-${i}"]`).textContent = marksFor(h2);
    board.querySelector(`[data-pts="0-${i}"]`).textContent = pts1 ? ('+'+pts1) : '';
    board.querySelector(`[data-pts="1-${i}"]`).textContent = pts2 ? ('+'+pts2) : '';
  });

  const total1 = state.hits[0].reduce((s,h,i)=> s + ((h>=3 && state.hits[1][i]<3) ? (h-3)*VALS[i] : 0), 0);
  const total2 = state.hits[1].reduce((s,h,i)=> s + ((h>=3 && state.hits[0][i]<3) ? (h-3)*VALS[i] : 0), 0);
  const closed1 = state.hits[0].filter(h=>h>=3).length;
  const closed2 = state.hits[1].filter(h=>h>=3).length;

  document.getElementById('score1').textContent = total1;
  document.getElementById('score2').textContent = total2;
  document.getElementById('closed1').textContent = closed1 + ' / 10 closed';
  document.getElementById('closed2').textContent = closed2 + ' / 10 closed';

  const n1 = state.names[0] || 'Player 1', n2 = state.names[1] || 'Player 2';
  const statusEl = document.getElementById('status');
  if(closed1===10 && total1>=total2) statusEl.textContent = n1 + ' wins! 🏆';
  else if(closed2===10 && total2>=total1) statusEl.textContent = n2 + ' wins! 🏆';
  else if(total1>total2) statusEl.textContent = n1 + ' is leading';
  else if(total2>total1) statusEl.textContent = n2 + ' is leading';
  else statusEl.textContent = 'Scores are tied';
}

function render(){ buildBoard(); update(); }

function renderLogo(idx){
  const logoEl = document.getElementById('logo'+(idx+1));
  logoEl.innerHTML = (state.logos[idx] ? `<img src="${state.logos[idx]}">` : '+')
    + `<input type="file" accept="image/png,image/jpeg" id="logoInput${idx+1}">`;
  document.getElementById('logoInput'+(idx+1)).addEventListener('change', (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = ()=>{
      state.logos[idx] = reader.result;
      save();
      renderLogo(idx);
    };
    reader.readAsDataURL(file);
  });
}

function setupPlayer(idx){
  const nameEl = document.getElementById('name'+(idx+1));
  nameEl.value = state.names[idx];
  nameEl.addEventListener('input', ()=>{ state.names[idx]=nameEl.value; save(); render(); });
  renderLogo(idx);
}
setupPlayer(0); setupPlayer(1);

document.getElementById('newGame').addEventListener('click', ()=>{
  state.hits = [new Array(10).fill(0), new Array(10).fill(0)];
  save(); render();
});
document.getElementById('resetAll').addEventListener('click', ()=>{
  state = {names:['Player 1','Player 2'], logos:[null,null], hits:[new Array(10).fill(0), new Array(10).fill(0)]};
  save();
  document.getElementById('name1').value='Player 1';
  document.getElementById('name2').value='Player 2';
  setupPlayer(0); setupPlayer(1);
  render();
});

render();
