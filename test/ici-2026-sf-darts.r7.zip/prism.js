/* Animated prism / geometric-lines background (canvas). */
(function prismBackground(){
  const host = document.getElementById('prismBg');
  if(!host) return;
  const canvas = document.createElement('canvas');
  host.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  const COLS = 12, ROWS = 8;            // mesh density (triangles = COLS*ROWS*2)
  let W = 0, H = 0, dpr = 1, pts = [], seeds = [], t0 = performance.now(), raf = 0;

  function resize(){
    dpr = Math.min(window.devicePixelRatio || 1, 1.5);   // cap for battery / speed
    W = host.clientWidth || innerWidth; H = host.clientHeight || innerHeight;
    canvas.width = Math.round(W*dpr); canvas.height = Math.round(H*dpr);
    canvas.style.width = W+'px'; canvas.style.height = H+'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);
    if(reduce) draw(0);
  }

  // one random phase set per vertex so every point drifts on its own orbit
  for(let j=0;j<=ROWS;j++) for(let i=0;i<=COLS;i++)
    seeds.push({px:Math.random()*6.28, py:Math.random()*6.28, sx:.25+Math.random()*.4, sy:.25+Math.random()*.4});

  function build(time){
    pts.length = 0;
    const cw = W/(COLS-2), ch = H/(ROWS-2);     // grid overshoots the screen so edges are never bare
    for(let j=0;j<=ROWS;j++) for(let i=0;i<=COLS;i++){
      const s = seeds[j*(COLS+1)+i];
      const amp = .34;
      pts.push({
        x: (i-1)*cw + Math.sin(time*s.sx + s.px)*cw*amp,
        y: (j-1)*ch + Math.cos(time*s.sy + s.py)*ch*amp
      });
    }
  }
  const P = (i,j) => pts[j*(COLS+1)+i];

  function hueFor(cx, cy, time){
    // hue sweeps across the screen and slowly cycles: teal → violet → magenta → orange
    const base = (cx/W)*150 + (cy/H)*70;
    return (base + time*14) % 360;
  }

  function draw(time){
    build(time);
    ctx.clearRect(0,0,W,H);
    ctx.fillStyle = '#0a0910'; ctx.fillRect(0,0,W,H);

    // prism facets
    for(let j=0;j<ROWS;j++) for(let i=0;i<COLS;i++){
      const a=P(i,j), b=P(i+1,j), c=P(i,j+1), d=P(i+1,j+1);
      const flip = ((i*7+j*13) % 2) === 0;
      const tris = flip ? [[a,b,c],[b,d,c]] : [[a,b,d],[a,d,c]];
      tris.forEach((tr,k)=>{
        const cx=(tr[0].x+tr[1].x+tr[2].x)/3, cy=(tr[0].y+tr[1].y+tr[2].y)/3;
        const shimmer = Math.sin(time*.9 + i*.7 + j*1.3 + k*2.1);        // -1..1, each facet pulses
        const light = 22 + shimmer*14 + Math.sin(cx*.004 + time*.6)*6;
        ctx.beginPath();
        ctx.moveTo(tr[0].x,tr[0].y); ctx.lineTo(tr[1].x,tr[1].y); ctx.lineTo(tr[2].x,tr[2].y); ctx.closePath();
        ctx.fillStyle = `hsl(${hueFor(cx,cy,time).toFixed(0)},70%,${light.toFixed(0)}%)`;
        ctx.fill();
      });
    }

    // glowing geometric lines over the facets
    ctx.lineWidth = 1;
    ctx.globalCompositeOperation = 'lighter';
    for(let j=0;j<=ROWS;j++) for(let i=0;i<=COLS;i++){
      const p = P(i,j);
      const h = hueFor(p.x,p.y,time)+40;
      const glow = .10 + .10*Math.max(0, Math.sin(time*1.1 + i*.9 - j*.6));
      ctx.strokeStyle = `hsla(${h.toFixed(0)},90%,70%,${glow.toFixed(3)})`;
      ctx.beginPath();
      if(i<COLS){ ctx.moveTo(p.x,p.y); ctx.lineTo(P(i+1,j).x,P(i+1,j).y); }
      if(j<ROWS){ ctx.moveTo(p.x,p.y); ctx.lineTo(P(i,j+1).x,P(i,j+1).y); }
      if(i<COLS && j<ROWS && ((i+j)%2===0)){ ctx.moveTo(p.x,p.y); ctx.lineTo(P(i+1,j+1).x,P(i+1,j+1).y); }
      ctx.stroke();
    }

    // bright light sweep travelling diagonally across the prism
    const sweep = ((time*.06) % 1.6) - .3;             // 0..1 across the diagonal, with off-screen margins
    const gx = sweep*(W+H) - H*.5;
    const g = ctx.createLinearGradient(gx - 160, 0, gx + 160, H);
    g.addColorStop(0,'rgba(255,255,255,0)');
    g.addColorStop(.5,'rgba(255,255,255,.13)');
    g.addColorStop(1,'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0,0,W,H);

    // twinkling vertices
    for(let n=0;n<pts.length;n+=3){
      const p = pts[n], tw = Math.max(0, Math.sin(time*1.6 + n*1.7));
      if(tw<.15) continue;
      ctx.fillStyle = `rgba(255,255,255,${(tw*.8).toFixed(2)})`;
      ctx.beginPath(); ctx.arc(p.x,p.y,1+tw*1.6,0,6.283); ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';

    // vignette so the scoreboard stays readable
    const v = ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.25, W/2,H/2,Math.max(W,H)*.75);
    v.addColorStop(0,'rgba(8,7,14,0)'); v.addColorStop(1,'rgba(8,7,14,.55)');
    ctx.fillStyle = v; ctx.fillRect(0,0,W,H);
  }

  function frame(now){
    draw((now - t0)/1000);
    raf = requestAnimationFrame(frame);
  }
  function start(){ if(!raf && !reduce) raf = requestAnimationFrame(frame); }
  function stop(){ if(raf){ cancelAnimationFrame(raf); raf = 0; } }

  addEventListener('resize', resize);
  document.addEventListener('visibilitychange', ()=> document.hidden ? stop() : start());
  resize();
  if(reduce) draw(3); else start();
})();
